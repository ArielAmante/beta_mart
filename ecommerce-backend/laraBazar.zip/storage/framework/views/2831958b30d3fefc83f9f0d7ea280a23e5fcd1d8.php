
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Order List</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard/Order list</li>
        </ol>
        <?php if($message = session('state')): ?>
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <?php echo e($message); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                DataTable Example
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Unit Price</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Address</th>
                            <th>Payment</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Unit Price</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Address</th>
                            <th>Payment</th>
                            <th>Status</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($order->uname); ?></td>
                            <td><?php echo e($order->pname); ?></td>
                            <td><?php echo e($order->pprice); ?></td>
                            <td><?php echo e($order->qty); ?></td>
                            <td><?php echo e($order->pprice*$order->qty); ?></td>
                            <td><?php echo e($order->address); ?></td>
                            <td><?php echo e($order->payment_method); ?></td>
                            <td>
                                <form action="<?php echo e(route('osc')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($order->id); ?>" name="id">
                                    <select name="status" id="">
                                        <option value="<?php echo e($order->status); ?>" selected disabled><?php echo e($order->status); ?></option>
                                        <option value="pending">pending</option>
                                        <option value="complete">complete</option>
                                    </select>
                                    <button type="submit" class="btn btn-secondary btn-sm">Save</button>
                                </form>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center">No record found</p>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/backend/pages/order_list.blade.php ENDPATH**/ ?>