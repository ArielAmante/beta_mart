
<?php $__env->startSection('content'); ?>
    <!-- search result section -->
    <main class="veiw-h">
        <div class="col-8 m-auto bg-white p-3 mt-3">
            <div class="row g-1 border-bottom">
                <h3 class="col-9">Shopping Cart</h2>
                <a class="btn btn-primary col-3 mb-1" href="/checkout">Order Now</a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border-bottom">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?php echo e(asset('storage/gallery/'.$product['gallery'])); ?>" class="img-fluid rounded-start" alt="product pic">
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">
                            <a href="detail/<?php echo e($product['id']); ?>" class="text-decoration-none underline">
                                <h5 class="card-title"><?php echo e($product['name']); ?></h5>
                                <p class="card-text text-truncate"> <?php echo e($product['description']); ?></p>
                            </a>
                            <p class="card-text">
                                <small class="text-danger"><b> Unit price:</b> ৳<?php echo e($product['price']); ?></small>
                                <small class="text-danger"><b> Qty:</b> <?php echo e($product['qty']); ?></small>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a class="btn btn-warning mt-3" href="/removeitem/<?php echo e($product['cart_id']); ?>" >Remove Item</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-danger fs-4 text-center">Soory, Cart is empty!!</div>
            <?php endif; ?>
        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/pages/cartlist.blade.php ENDPATH**/ ?>