
<?php $__env->startSection('content'); ?>
    <!-- search result section -->
    <div class="col-8 m-auto">
        <h3 class="mt-3 text-center">Search items found for "<?php echo e($query); ?>"</h2>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card my-3  m-auto" style="max-width: 540px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo e($product['gallery']); ?>" class="img-fluid rounded-start" alt="product pic">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <a href="detail/<?php echo e($product['id']); ?>" class="text-decoration-none underline">
                            <h5 class="card-title"><?php echo e($product['name']); ?></h5>
                            <p class="card-text"><?php echo e($product['description']); ?></p>
                        </a>
                        <p class="card-text"><small class="text-danger">৳<?php echo e($product['price']); ?></small></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-danger fs-4 text-center">Soory, No result found!!</div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/pages/search.blade.php ENDPATH**/ ?>