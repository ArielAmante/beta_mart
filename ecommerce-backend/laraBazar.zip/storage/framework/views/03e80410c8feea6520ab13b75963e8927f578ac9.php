
<?php $__env->startSection('content'); ?>
<!-- Product-page -->
  <Div class="row my-4 container bg-light m-auto">
      <div class="col-12 col-md-6">
          <img src="<?php echo e(asset('storage/gallery/'.$product['gallery'])); ?>" alt="Product image" class="card-img"> 
      </div>
      <div class="col-12 col-md-6 mt-5">
          <h4><?php echo e($product->name); ?></h4> 
          <div class="ratings text-warning">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-alt"></i>
              <i class="fa fa-star-o"></i>
              (2)
          </div>
          <p><b>Brand: </b> Sony</p>
          <p><b>Category: </b> <?php echo e($product->category); ?></p>
          <p><b>Price: </b>৳<?php echo e($product->price); ?></p>
          <p> 
              <form action="/add_to_cart" method="post">
                <?php echo csrf_field(); ?>
                <label for="qu"><b>Quantity:</b> </label> 
                <input class="form-control-sm text-center me-3" id="qty" type="number" name="qty" min="1" value="1" style="max-width: 5rem" required />
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <br>
                <button href="#" class="btn btn-outline-primary mt-3" type="submit" id="button-addon1" >
                    <i class="fas fa-cart-plus px-2"></i> Add To Cart
                </button>
              </form>
            </p> 
      </div>
      <div class="col-12 bg-light mt-3 border-top">
          <div class="p-3 details-2 ">
              <h4 class="fw-bold">Product Details</h3>
              <p><?php echo e($product->description); ?></p>
          </div>
      </div>
  </Div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/pages/detail.blade.php ENDPATH**/ ?>