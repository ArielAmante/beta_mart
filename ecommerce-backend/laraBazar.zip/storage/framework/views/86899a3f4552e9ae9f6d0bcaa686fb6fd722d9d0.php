
<?php $__env->startSection('content'); ?>
    <!-- search result section -->
    <div class="container veiw-h">
        <div class="alert alert-success position-absolute top-50 start-50 translate-middle" role="alert">
            <h4 class="alert-heading">Well done!</h4>
            <p>Aww yeah, you successfully place your order.</p>
            <hr>
            <div class="mb-0 d-grid gap-2 col-7 mx-auto">
                <a class="btn btn-primary" href="/">Continue Shopping <i class="fas fa-play"></i></a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/pages/orderstatus.blade.php ENDPATH**/ ?>