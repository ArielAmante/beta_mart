
<?php $__env->startSection('content'); ?>
<h1>
    login page
</h1>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\laraBazar\resources\views/login.blade.php ENDPATH**/ ?>